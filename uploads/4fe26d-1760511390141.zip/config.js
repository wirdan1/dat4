// config.js
export const config = {
    githubToken: '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', // Ganti dengan token GitHub Anda
    owner: 'wirdan1', // Ganti dengan username GitHub Anda
    branch: 'main',
    repos: ['dat1', 'dat2', 'dat3', 'dat4']
};